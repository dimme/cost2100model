function H_omni = creat_FR_omni(link,freq,delta_f)
% link: simulated results from the COST 2100 channel model
% freq: start frequency and end frequency
% delta_f: the difference between two frequency bins


first_snapshot = 1;
last_snapshot_unpol = size(link.channel_unpol,2);
last_snapshot_pol = size(link.channel_pol,2);
bandwidth = freq(2)-freq(1);

H = [];
for ii = first_snapshot:last_snapshot_unpol  
    channel1 = link.channel{ii}.h; 
    channel2 = link.channel{ii}.h_los;
    channel = [channel1 ;channel2];
    MPC_delay = channel(:,5);    
    MPC_amp = channel(:,6); 
    Hf=[];
    Nfreq = freq(1):delta_f:freq(2);    
    for I = 1:length(Nfreq)
        Hf(I) = sum((MPC_amp).*exp(-1j*2*pi*Nfreq(I)*MPC_delay));        
    end  
    H(ii,:) = Hf;
end

H_omni = H;
