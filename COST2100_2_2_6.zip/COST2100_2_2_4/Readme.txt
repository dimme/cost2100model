\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
The updated version is implemented by Meifang Zhu, Lund University, Sweden. Now the framework is including outdoor LOS and NLOS parameters as well. It also can been used for outdoor LOS multiple link simulations.

script demo_model.m provide the possible accesses for scenario setup, also it generates a omni-directional antenna frequency response.

The modifications are listed in document changelog.

Meifang Zhu, 2013.01.18.
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
This is the single-link version COST2100 channel model implementation. The code is developed under GPL. The code is currently maintained by Lingfeng Liu, Universti� catholique de Louvain (UCL). For any problem and question, please directly contact us via: 
email: lingfeng.liu@uclouvain.be
tel: +32 (0) 10 47 81 05
address: B�timent Maxwell, Place du Levent 3, 1348 Louvain-la-Neuve, Belgium

N.B. CONTACT ME IF YOU WANT TO HAVE A MULTI-LINK VERSION
We have developped a multi-link cost 2100 channel model based on TD11012. If you are interested on testing, evaluating, or validating it, don't hesitate to let us know. The multi-link version will be finally available to public at the end of COST2100 action. 

1,Function list
calc_dist
calc_pathloss
cost2100
demo_model
draw_circ
draw_ellpsoid
get_channel
get_channel_los
get_cluster_local
get_common
get_cluster
get_dmc
get_H
get_IR
get_mpc
get_para
get_VR
get_VRLOS
get_VRtable
rotate_matrix
setFontsize
update_chan
visual_pddp
visual_channel

2,Other files list
unit.txt: list of parameter unit defined in the model
antSample.mat: antenna array radiation pattern sample file

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
3, How to run the code

The main routine of the code is cost2100

The visualization routines are named as 'visual_*'

To understand each function,  type help function_name in matlab

The test script is demo_model.m
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
4, How to customize the channel implementation

Please read get_para for more instructions

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
5, Copyright
Copyright (C)2008 LIU Ling-Feng, Universit� catholique de Louvain, Belgium
This program, cost2100, is free software: you can redistribute it and/or 
modify it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or(at your 
option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

6, Acknowledgements
Thanks for Helmut Hofstetter for his previous code on the COST 273 
channel model which inspires me a lot.

Thanks for Claude Oestges and Nicolai Czink for their feedbacks and theory 
supports.

Thanks for Katsuyuki Haneda, Juho Putane, Fredrik Tufvesson, and Meifang 
Zhu for their active participations and code testing.

Also thanks for my wife Qin, always be patient during my coding time.

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
7, Reference

[1] L.M. Correia, Mobile Broadband Multimedia Networks. Academic Press, 2006.
[2] N. Czink and C. Oestges, �The COST 273 MIMO channel model: Three kinds of clusters,� IEEE 10th Int. Sym., ISSSTA�08, pp. 282�286, 2008.
[3] L. Liu, N. Czink, and C. Oestges, Implementing the COST 273 MIMO channel model, NEWCOM 2009