clear all; clc;
close all
network = 'aaltoOLOS'
Link = 'Single'
switch network
   %%%%%%%%%%%%%%%
    case '300MHz_FOI'
   %%%%%%%%%%%%%%%  
   switch Link
       case 'Single'
            scenario = 'LOS' % can be NLOS as well
            % initialize frequency and snapshot rate
            freq = [2.75e8 2.95e8]; %Hz
            snapRate = 1; % dececides the resolution between two snapshots
            snapNum = 100;         
            BSPos  = [0 0 0];
            MSPos  = [100 -200 0];%m
            MSVelo = [-0.2 0.9 0];%m
       case 'Multiple'
            scenario = 'LOS' % Now is only LOS is accessable
            % initialize frequency and snapshot rate
            freq = [2.75e8 2.95e8]; %Hz
            snapRate = 1; % dececides the resolution between two snapshots
            snapNum = 100;         
            BSPos  = [0 0 0];
            MSPos  = [100 -200 0;
                      120 -200 0];%m
            MSVelo = [-0.2 0.9 0;
                      -0.2 0.9 0];%m
   end
   %%%%%%%%%%%%%%%
    case 'aaltoOLOS'
   %%%%%%%%%%%%%%%
        scenario = 'OLOS'
        freq = [-60e6 60e6]+5.3e9; %Hz
        snapRate = 1; %/s
        snapNum = 100;
        BSPos  = [
                  10   10  0;];
        MSPos  = [
                  10   5   0];

        MSVelo = [
                  0    1   0];
end

%% get the MPCs from the COST 2100 channel model
[paraEx paraSt link env BS MS ] = cost2100(network, scenario, Link, freq, snapRate, snapNum, BSPos,MSPos,MSVelo);


switch Link
    case 'Single'
        %% reconstruct the channel transfer funtion with an omni-directional antenna for single link simulation
        delta_f = 7.8125e4;% the difference between two frequency bins
        H_omni = creat_FR_omni(link,freq,delta_f);
        figure,mesh((freq(1):delta_f:freq(2))*1e-6,1:size(H_omni,1),10*log10(abs(H_omni)))
        xlabel('Frequency [MHz]')
        ylabel('Snapshots')
        zlabel('Power [dB]')
        
    case 'Multiple'
        %% reconstruct the channel transfer funtion with an omni-directional antenna for multiple link simulation
        delta_f = 7.8125e4;% the difference between two frequency bins
        H_omni_1 = creat_FR_omni(link(1),freq,delta_f);
        H_omni_2 = creat_FR_omni(link(2),freq,delta_f);
       
        figure,mesh((freq(1):delta_f:freq(2))*1e-6,1:size(H_omni_1,1),10*log10(abs(H_omni_1)))
        xlabel('Frequency [MHz]')
        ylabel('Snapshots')
        zlabel('Power [dB]')       
        title('Frequency response for simulated link 1')
        
        figure,mesh((freq(1):delta_f:freq(2))*1e-6,1:size(H_omni_2,1),10*log10(abs(H_omni_2)))
        xlabel('Frequency [MHz]')
        ylabel('Snapshots')
        zlabel('Power [dB]')
        title('Frequency response for simulated link 2')        
end
