function pol = get_pol(cluster, paraSt)
%GET_POL Generate four polization matrix of path n belonging to the cluster
%m
%Default call: pol = get_pol(cluster, paraSt)
%-------
%Input:
%-------
%cluster: cluster information
%paraSt: stochastic parameters
%-------
%Output:
%-------
%pol: polarization information
% .Gamma(numMPC): Four channel polarization matrix, normalized
%See also: get_cluster, get_para, COST2100
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Copyright (C)2014 Usman Tahir Virk, RAD, Aalto, Finland 
%This file is part of cost2100.
%This program is free software: you can redistribute it and/or modify
%it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or
%(at your option) any later version.
%
%This program is distributed in the hope that it will be useful,
%but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License
%along with this program.  If not, see <http://www.gnu.org/licenses/>.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n_c = length(cluster); %Number of far clusters
n_mpc = paraSt.n_mpc; %Number of MPCs per cluster
mu_xpdv = paraSt.mu_xpdv; %Mean of XPD verticle component 
sigma_xpdv = paraSt.sigma_xpdv; %Standard deviation of XPD verticle component
mu_xpdh = paraSt.mu_xpdh; %Mean of XPD horizontal component 
sigma_xpdh = paraSt.sigma_xpdh; %Standard deviation of XPD horizontal component 
mu_cpr = paraSt.mu_cpr; %Mean of CPR  
sigma_cpr = paraSt.sigma_cpr; %Standard deviation of CPR 

for m = 1:n_c 
    XPD_h = lognrnd(mu_xpdh,sigma_xpdh,[1 n_mpc]);
    XPD_v = lognrnd(mu_xpdv,sigma_xpdv,[1 n_mpc]);
    CPR = lognrnd(mu_cpr,sigma_cpr,[1 n_mpc]);
    
    Gamma11 = ones(1,n_mpc); % to get same verticle polarization in channel 
    Gamma12 = exp(1j*2*pi*rand(1,n_mpc))./sqrt(XPD_h.*CPR);
    Gamma21 = exp(1j*2*pi*rand(1,n_mpc))./sqrt(XPD_v);
    Gamma22 = exp(1j*2*pi*rand(1,n_mpc))./sqrt(CPR);
    Gamma = [Gamma11; Gamma12; Gamma21; Gamma22];
    for i = 1:size(Gamma,2)
        Gamma_fnorm = norm(Gamma(:,i),'fro');
        Gamma_norm(:,i) = Gamma(:,i)/Gamma_fnorm;
    end
     
    pol(m).Gamma = Gamma_norm;    
end

