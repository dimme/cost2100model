1,Function list
calc_dist
calc_pathloss
cost2100
DB
demo_model
draw_circ
draw_ellpsoid
get_channel
get_channel_los
get_cluster_local
get_common
get_cluster
get_mpc
get_para
get_VR
get_VRLOS
rotate_matrix
setFontsize
update_chan
visual_cluster
visual_pddp
visual_VR
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
2, How to run the code

The main routine of the code is cost2100

The visualization routines are named as 'visual_*'

To understand each function,  type help function_name in matlab

The test script is demo_model.m

2.SP, How to customize the channel implementation
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
3, Copyright
Copyright (C)2008 LIU Ling-Feng, Universit� catholique de Louvain, Belgium
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
4, Acknowledgements
Thanks Helmut Hofstetter for his previous coding on the COST 273 channel model 
which  inspire me quite a lot.

Thanks Claude Oestges and Nicolai Czink for their feedbacks and theory supports.

Also thanks for my wife Qin for her patience during my process of "code 
debugging".